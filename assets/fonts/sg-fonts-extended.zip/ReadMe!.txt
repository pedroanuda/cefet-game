Thank you for downloading the SG Font Collection!

This is a set of pixel fonts meant for games and other projects. These are licensed under CC0, meaning you can use them however you want - credit is optional but appreciated. If you enjoyed these fonts, check out our other projects at spicygame.itch.io.

spicygame.itch.io/fonts
